# Pulse Grid — GitHub-Ready Android Project

This repository builds the Pulse Grid Android APK automatically with GitHub Actions.

## Phone-only setup

1. Create/sign in to GitHub in your phone browser.
2. Create a new repository, e.g. `pulse-grid-android`.
3. Upload **all files and folders inside this ZIP** to the repository.
4. Commit to `main`.
5. Open the repository's **Actions** tab.
6. Open **Build Pulse Grid APK**.
7. Tap **Run workflow** if it isn't already running.
8. Wait for the build to finish.
9. Open the completed workflow run.
10. Scroll to **Artifacts** and download `PulseGrid-debug-apk`.
11. Extract the downloaded artifact and install `app-debug.apk` on your Android phone.

## Notes

- The workflow creates a debug APK. It is suitable for testing/installing on your phone.
- For Google Play Store publishing, a release build must be signed with a private upload key and the project should be configured for release signing.
- Application ID: `com.pulsegrid.app`
- App name: `Pulse Grid`
