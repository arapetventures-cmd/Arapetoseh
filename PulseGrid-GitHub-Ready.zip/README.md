# Pulse Grid — Android Studio Project

This is a native Android Studio wrapper around the Pulse Grid web drum machine.

## Build
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Select `app`.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. The debug APK will be under:
   `app/build/outputs/apk/debug/app-debug.apk`

## Notes
- The drum sequencer UI/audio is bundled locally in `app/src/main/assets/index.html`.
- It works offline.
- JavaScript and Web Audio are enabled.
- Package/application ID: `com.pulsegrid.app`
- Version: 1.0 (versionCode 1)
