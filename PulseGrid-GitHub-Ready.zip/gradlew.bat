@echo off
setlocal
set GRADLE_VERSION=8.9
set DIST=%USERPROFILE%\.gradle\pulse-grid\gradle-%GRADLE_VERSION%
if not exist "%DIST%\bin\gradle.bat" (
  powershell -NoProfile -Command "$u='https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip'; $z=$env:USERPROFILE+'\.gradle\pulse-grid\gradle.zip'; New-Item -ItemType Directory -Force -Path ($env:USERPROFILE+'\.gradle\pulse-grid') | Out-Null; Invoke-WebRequest $u -OutFile $z; Expand-Archive -Force $z ($env:USERPROFILE+'\.gradle\pulse-grid\extract'); Move-Item ($env:USERPROFILE+'\.gradle\pulse-grid\extract\gradle-%GRADLE_VERSION%') '%DIST%'; Remove-Item -Recurse -Force ($env:USERPROFILE+'\.gradle\pulse-grid\extract'); Remove-Item $z"
)
)
"%DIST%\bin\gradle.bat" %*
